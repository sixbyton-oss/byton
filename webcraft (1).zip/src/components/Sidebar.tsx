import { Link, useLocation } from "react-router-dom";
import { getCurrentUser } from "../utils/auth";
import { getActivePackage, getStoredPackageData } from "../utils/packageStorage";

export default function Sidebar() {
  const location = useLocation();
  const user = getCurrentUser();
  const pkg = getActivePackage();
  const stored = getStoredPackageData();

  const links = [
    { to: "/", label: "Home", icon: "🏠" },
    { to: "/builder", label: "AI Builder", icon: "✨" },
    { to: "/pricing", label: "Pricing", icon: "💎" },
    { to: "/support", label: "Support", icon: "💬" },
  ];

  return (
    <aside className="sticky top-[68px] hidden h-[calc(100vh-68px)] w-64 flex-shrink-0 flex-col border-r border-white/10 bg-black/60 p-4 lg:flex">
      <nav className="space-y-1">
        {links.map((l) => {
          const active = l.to === "/" ? location.pathname === "/" : location.pathname.startsWith(l.to);
          return (
            <Link
              key={l.to}
              to={l.to}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                active
                  ? "bg-lime-400/15 text-lime-300 ring-1 ring-lime-400/30"
                  : "text-white/80 hover:bg-white/5 hover:text-white"
              }`}
            >
              <span>{l.icon}</span>
              {l.label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-6 border-t border-white/10 pt-4">
        <p className="px-3 text-xs font-bold uppercase tracking-wider text-white/40">Account</p>
        <div className="mt-2 space-y-1">
          {user ? (
            <>
              <Link
                to="/account"
                className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-white/80 hover:bg-white/5 hover:text-white"
              >
                <span>👤</span>
                <div className="min-w-0">
                  <div className="truncate">{user.username}</div>
                  <div className="truncate text-xs text-white/50">{user.email}</div>
                </div>
              </Link>
              {stored && stored.status === "pending" && (
                <Link
                  to="/account"
                  className="flex items-center gap-3 rounded-lg bg-amber-500/10 px-3 py-2.5 text-sm font-medium text-amber-300 ring-1 ring-amber-500/30"
                >
                  <span>⏳</span>
                  Payment pending
                </Link>
              )}
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-white/80 hover:bg-white/5 hover:text-white"
              >
                <span>🔐</span>
                Login
              </Link>
              <Link
                to="/signup"
                className="flex items-center gap-3 rounded-lg bg-lime-400 px-3 py-2.5 text-sm font-bold text-black hover:bg-lime-300"
              >
                <span>🚀</span>
                Create account
              </Link>
            </>
          )}
        </div>
      </div>

      {pkg && (
        <div className="mt-auto rounded-xl border border-white/10 bg-white/5 p-4">
          <p className="text-xs font-bold uppercase tracking-wider text-white/50">Current plan</p>
          <p className="mt-1 text-lg font-extrabold text-white">
            {pkg.name}
            {pkg.id !== "starter" && <span className="ml-1 text-lime-400">★</span>}
          </p>
          <p className="text-xs text-white/60">{pkg.limit}</p>
        </div>
      )}
    </aside>
  );
}
