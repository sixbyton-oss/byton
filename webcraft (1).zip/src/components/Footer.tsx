import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-lime-400 to-lime-600 text-black shadow-lg shadow-lime-500/30">
                <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5">
                  <path d="M4 7l8-4 8 4-8 4-8-4zm0 5l8 4 8-4M4 17l8 4 8-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <span className="text-lg font-extrabold tracking-tight text-white">Web<span className="text-lime-400">craft</span></span>
            </div>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-white/70">
              The fastest prompt-to-website builder. Describe what you need and our AI crafts a production-ready website you can deploy anywhere.
            </p>
            <div className="mt-5 flex flex-col gap-1 text-sm text-white/70">
              <a href="mailto:sixbyton@gmail.com" className="hover:text-lime-300">✉️ sixbyton@gmail.com</a>
              <a href="https://wa.me/263786443311" target="_blank" rel="noreferrer" className="hover:text-lime-300">💬 WhatsApp: +263 786 443 311</a>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Product</h4>
            <ul className="mt-3 space-y-2 text-sm text-white/70">
              <li><Link to="/builder" className="hover:text-lime-300">AI Builder</Link></li>
              <li><Link to="/pricing" className="hover:text-lime-300">Pricing</Link></li>
              <li><Link to="/support" className="hover:text-lime-300">Support</Link></li>
              <li><Link to="/login" className="hover:text-lime-300">Login</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">Legal</h4>
            <ul className="mt-3 space-y-2 text-sm text-white/70">
              <li><Link to="/privacy" className="hover:text-lime-300">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-lime-300">Terms of Service</Link></li>
              <li><Link to="/cookies" className="hover:text-lime-300">Cookies</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/50 sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} Webcraft. All rights reserved.</p>
          <p>Built with ⚡ in Zimbabwe • Prompt. Preview. Deploy.</p>
        </div>
      </div>
    </footer>
  );
}
