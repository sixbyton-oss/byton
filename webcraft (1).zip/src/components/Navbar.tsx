import { Link, NavLink, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { getActivePackage, getStoredPackageData } from "../utils/packageStorage";
import { getCurrentUser, isPremiumUser } from "../utils/auth";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const user = getCurrentUser();
  const pkg = getActivePackage();
  const stored = getStoredPackageData();
  const premium = isPremiumUser();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  const links = [
    { to: "/", label: "Home" },
    { to: "/builder", label: "AI Builder" },
    { to: "/pricing", label: "Pricing" },
    { to: "/support", label: "Support" },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-black/60 bg-black/80 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-lime-400 to-lime-600 text-black shadow-lg shadow-lime-500/30">
            <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5">
              <path
                d="M4 7l8-4 8 4-8 4-8-4zm0 5l8 4 8-4M4 17l8 4 8-4"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <span className="text-lg font-extrabold tracking-tight text-white">
            Web<span className="text-lime-400">craft</span>
          </span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) =>
                `rounded-lg px-3 py-2 text-sm font-medium transition ${
                  isActive
                    ? "bg-lime-400/15 text-lime-300"
                    : "text-white/80 hover:bg-white/5 hover:text-white"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {stored && stored.status === "pending" && (
            <Link
              to="/account"
              className="hidden items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-3 py-1 text-xs font-medium text-amber-300 sm:flex"
            >
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" />
              Payment pending
            </Link>
          )}
          {pkg && (
            <span className={`hidden items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium sm:flex ${
              premium
                ? "border-lime-500/40 bg-lime-500/10 text-lime-300"
                : "border-white/20 bg-white/5 text-white/80"
            }`}>
              <span className={`h-1.5 w-1.5 rounded-full ${premium ? "bg-lime-400" : "bg-white/60"}`} />
              {pkg.name}
              {premium && <span>★</span>}
            </span>
          )}

          {user ? (
            <Link
              to="/account"
              className="hidden items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-white hover:bg-white/10 sm:flex"
            >
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-lime-400 to-lime-600 text-xs font-bold text-black">
                {user.username.charAt(0).toUpperCase()}
              </div>
              <span className="max-w-[120px] truncate">{user.username}</span>
            </Link>
          ) : (
            <Link
              to="/login"
              className="hidden rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm font-medium text-white hover:bg-white/10 sm:inline-block"
            >
              Login
            </Link>
          )}

          <Link
            to="/builder"
            className="hidden rounded-lg bg-lime-400 px-4 py-2 text-sm font-bold text-black shadow-lg shadow-lime-400/30 transition hover:bg-lime-300 hover:shadow-lime-400/50 sm:inline-block"
          >
            Build now
          </Link>

          <button
            onClick={() => setOpen(!open)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-white md:hidden"
            aria-label="Toggle menu"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
              {open ? (
                <path d="M6 6l12 12M6 18L18 6" strokeLinecap="round" />
              ) : (
                <path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round" />
              )}
            </svg>
          </button>
        </div>
      </nav>
      {open && (
        <div className="border-t border-white/10 bg-black md:hidden">
          <div className="space-y-1 px-4 py-3">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                className={({ isActive }) =>
                  `block rounded-lg px-3 py-2 text-sm font-medium ${
                    isActive ? "bg-lime-400/15 text-lime-300" : "text-white hover:bg-white/5"
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
            <div className="mt-2 flex gap-2">
              {user ? (
                <Link to="/account" className="flex-1 rounded-lg border border-white/10 bg-white/5 py-2 text-center text-sm font-medium text-white">
                  Account
                </Link>
              ) : (
                <Link to="/login" className="flex-1 rounded-lg border border-white/10 bg-white/5 py-2 text-center text-sm font-medium text-white">
                  Login
                </Link>
              )}
              <Link
                to="/builder"
                className="flex-1 rounded-lg bg-lime-400 py-2 text-center text-sm font-bold text-black"
              >
                Build now
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
