import type { PackageId } from "./packageStorage";

export type OrderStatus = "pending" | "approved" | "rejected";

export interface Order {
  id: string;
  userEmail: string;
  username: string;
  packageId: PackageId;
  amount: string;
  ecoCashCode: string;
  senderNumber: string;
  senderName: string;
  submittedAt: number;
  status: OrderStatus;
  reviewedAt?: number;
}

const ORDERS_KEY = "webcraft_orders";

export function getOrders(): Order[] {
  try {
    return JSON.parse(localStorage.getItem(ORDERS_KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveOrders(orders: Order[]) {
  localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
}

export function createOrder(order: Omit<Order, "id" | "submittedAt" | "status">): Order {
  const newOrder: Order = {
    ...order,
    id: `ORD-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    submittedAt: Date.now(),
    status: "pending",
  };
  const orders = getOrders();
  orders.unshift(newOrder);
  saveOrders(orders);
  return newOrder;
}

export function getUserOrders(email: string): Order[] {
  return getOrders().filter((o) => o.userEmail.toLowerCase() === email.toLowerCase());
}

export function updateOrderStatus(id: string, status: OrderStatus): Order | null {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === id);
  if (idx === -1) return null;
  orders[idx].status = status;
  orders[idx].reviewedAt = Date.now();
  saveOrders(orders);
  return orders[idx];
}

export function buildWhatsAppMessage(order: Order): string {
  const pkgLabel = order.packageId === "classic" ? "Classic ($1)" : "Pro ($5)";
  return (
    `Hi Webcraft team! 👋\n\n` +
    `I just submitted a payment for the *${pkgLabel}* package.\n\n` +
    `📋 *Order ID:* ${order.id}\n` +
    `👤 *Name:* ${order.senderName}\n` +
    `📞 *Sender number:* ${order.senderNumber}\n` +
    `🧾 *EcoCash confirmation code:* ${order.ecoCashCode}\n` +
    `💰 *Amount:* ${order.amount}\n` +
    `📧 *Account email:* ${order.userEmail}\n\n` +
    `Please activate my account once verified. Thanks!`
  );
}

export function openWhatsApp(order: Order) {
  const msg = encodeURIComponent(buildWhatsAppMessage(order));
  window.open(`https://wa.me/263786443311?text=${msg}`, "_blank");
}
