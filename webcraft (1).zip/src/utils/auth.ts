// Lightweight client-side auth using localStorage.
// Passwords are hashed with SHA-256 so they are not stored in plaintext.

export interface User {
  username: string;
  email: string;
  passwordHash: string;
  createdAt: number;
}

const USERS_KEY = "webcraft_users";
const SESSION_KEY = "webcraft_session";

export async function hashPassword(pw: string): Promise<string> {
  const enc = new TextEncoder().encode(pw);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function getUsers(): User[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveUsers(users: User[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function findUser(email: string): User | undefined {
  return getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export async function signup(
  username: string,
  email: string,
  password: string
): Promise<User> {
  if (!username.trim()) throw new Error("Username is required");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Invalid email");
  if (password.length < 6) throw new Error("Password must be at least 6 characters");
  if (findUser(email)) throw new Error("An account with this email already exists");

  const user: User = {
    username: username.trim(),
    email: email.toLowerCase().trim(),
    passwordHash: await hashPassword(password),
    createdAt: Date.now(),
  };
  const users = getUsers();
  users.push(user);
  saveUsers(users);
  return user;
}

export async function login(email: string, password: string): Promise<User> {
  const user = findUser(email);
  if (!user) throw new Error("No account found with that email");
  const hash = await hashPassword(password);
  if (hash !== user.passwordHash) throw new Error("Incorrect password");
  return user;
}

export function setSession(email: string) {
  localStorage.setItem(SESSION_KEY, email.toLowerCase().trim());
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

export function getCurrentUser(): User | null {
  const email = localStorage.getItem(SESSION_KEY);
  if (!email) return null;
  return findUser(email) || null;
}

export function isPremiumUser(): boolean {
  // A premium user has an approved Classic or Pro package.
  // We import lazily to avoid circular deps.
  const raw = localStorage.getItem("webcraft_package");
  if (!raw) return false;
  try {
    const data = JSON.parse(raw);
    return data.status === "active" && (data.id === "classic" || data.id === "pro");
  } catch {
    return false;
  }
}
