import { getUsers, saveUsers } from "./auth";
import { getOrders, saveOrders, type Order } from "./orders";

export type PackageId = "starter" | "classic" | "pro";

export interface PackageInfo {
  id: PackageId;
  name: string;
  price: string;
  priceValue: number;
  period: string;
  limit: string;
  features: string[];
  highlight?: boolean;
  badge?: string;
  requiresPayment: boolean;
}

export const PACKAGES: PackageInfo[] = [
  {
    id: "starter",
    name: "Starter",
    price: "Free",
    priceValue: 0,
    period: "forever",
    limit: "4 prompts / 24 hrs",
    features: [
      "4 AI prompts every 24 hours",
      "Standard templates",
      "HTML + CSS export",
      "Community support",
    ],
    requiresPayment: false,
  },
  {
    id: "classic",
    name: "Classic",
    price: "$1",
    priceValue: 1,
    period: "per 24 hours",
    limit: "Unlimited prompts / 24 hrs",
    features: [
      "Unlimited prompts for 24 hours",
      "Premium templates",
      "HTML + CSS + JS export",
      "Priority email support",
      "No Webcraft watermark",
    ],
    highlight: true,
    badge: "Most popular",
    requiresPayment: true,
  },
  {
    id: "pro",
    name: "Pro",
    price: "$5",
    priceValue: 5,
    period: "per week",
    limit: "Unlimited prompts / 7 days",
    features: [
      "Unlimited prompts for 7 days",
      "All premium templates",
      "Full-stack export (multi-page ZIP)",
      "WhatsApp priority support",
      "Early access to new features",
    ],
    requiresPayment: true,
  },
];

const PACKAGE_KEY = "webcraft_package";
const COUNT_KEY = "webcraft_prompt_count";

export interface StoredPackage {
  id: PackageId;
  userEmail: string;
  selectedAt: number;
  expiresAt: number | null;
  status: "pending" | "active";
  orderId?: string;
}

export function getActivePackage(): PackageInfo | null {
  const raw = localStorage.getItem(PACKAGE_KEY);
  if (!raw) return null;
  try {
    const data: StoredPackage = JSON.parse(raw);
    // starter is always active if stored
    if (data.id === "starter" && data.status === "active") {
      return PACKAGES.find((p) => p.id === "starter") || null;
    }
    // paid packages must be active status AND not expired
    if (data.status !== "active") return null;
    if (data.expiresAt && Date.now() > data.expiresAt) {
      localStorage.removeItem(PACKAGE_KEY);
      localStorage.removeItem(COUNT_KEY);
      return null;
    }
    return PACKAGES.find((p) => p.id === data.id) || null;
  } catch {
    return null;
  }
}

export function getStoredPackageData(): StoredPackage | null {
  const raw = localStorage.getItem(PACKAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/** Activate starter immediately (no payment needed) */
export function selectStarter(userEmail: string): PackageInfo {
  const data: StoredPackage = {
    id: "starter",
    userEmail,
    selectedAt: Date.now(),
    expiresAt: null,
    status: "active",
  };
  localStorage.setItem(PACKAGE_KEY, JSON.stringify(data));
  localStorage.removeItem(COUNT_KEY);
  return PACKAGES.find((p) => p.id === "starter")!;
}

/** Create a pending paid package — will be activated by admin after order approval */
export function selectPaidPackage(
  id: "classic" | "pro",
  userEmail: string,
  orderId: string
): StoredPackage {
  const expiresAt =
    id === "classic"
      ? Date.now() + 24 * 60 * 60 * 1000
      : Date.now() + 7 * 24 * 60 * 60 * 1000;
  const data: StoredPackage = {
    id,
    userEmail,
    selectedAt: Date.now(),
    expiresAt,
    status: "pending",
    orderId,
  };
  localStorage.setItem(PACKAGE_KEY, JSON.stringify(data));
  return data;
}

/** Called by admin when approving an order — flips status to active */
export function approvePackageForUser(userEmail: string, packageId: PackageId) {
  // Update stored package if this user is currently logged in
  const stored = getStoredPackageData();
  if (stored && stored.userEmail.toLowerCase() === userEmail.toLowerCase()) {
    stored.status = "active";
    stored.selectedAt = Date.now();
    if (packageId === "classic") stored.expiresAt = Date.now() + 24 * 60 * 60 * 1000;
    if (packageId === "pro") stored.expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
    localStorage.setItem(PACKAGE_KEY, JSON.stringify(stored));
    localStorage.removeItem(COUNT_KEY);
  }

  // Also mark the user as premium by storing a flag on their user record (used across sessions)
  const users = getUsers();
  const u = users.find((x) => x.email.toLowerCase() === userEmail.toLowerCase());
  if (u) {
    (u as any).premium = true;
    (u as any).premiumPackage = packageId;
    (u as any).premiumActivatedAt = Date.now();
    saveUsers(users);
  }
}

export function clearPackage(): void {
  localStorage.removeItem(PACKAGE_KEY);
  localStorage.removeItem(COUNT_KEY);
}

export interface PromptUsage {
  used: number;
  limit: number | null; // null = unlimited
  remaining: number | null;
  resetAt: number | null;
  percent: number; // 0..100
}

export function recordPrompt(): { allowed: boolean; usage: PromptUsage } {
  const pkg = getActivePackage();
  const empty: PromptUsage = { used: 0, limit: 0, remaining: 0, resetAt: null, percent: 100 };
  if (!pkg) return { allowed: false, usage: empty };

  if (pkg.id === "classic" || pkg.id === "pro") {
    const raw = localStorage.getItem(PACKAGE_KEY);
    const data = raw ? (JSON.parse(raw) as StoredPackage) : null;
    return {
      allowed: true,
      usage: {
        used: 0,
        limit: null,
        remaining: null,
        resetAt: data?.expiresAt || null,
        percent: 0,
      },
    };
  }

  // starter
  const raw = localStorage.getItem(COUNT_KEY);
  const now = Date.now();
  let record: { count: number; windowStart: number } = raw
    ? JSON.parse(raw)
    : { count: 0, windowStart: now };
  if (now - record.windowStart > 24 * 60 * 60 * 1000) {
    record = { count: 0, windowStart: now };
  }
  if (record.count >= 4) {
    return {
      allowed: false,
      usage: {
        used: record.count,
        limit: 4,
        remaining: 0,
        resetAt: record.windowStart + 24 * 60 * 60 * 1000,
        percent: 100,
      },
    };
  }
  record.count += 1;
  localStorage.setItem(COUNT_KEY, JSON.stringify(record));
  return {
    allowed: true,
    usage: {
      used: record.count,
      limit: 4,
      remaining: 4 - record.count,
      resetAt: record.windowStart + 24 * 60 * 60 * 1000,
      percent: (record.count / 4) * 100,
    },
  };
}

export function getUsage(): PromptUsage {
  const pkg = getActivePackage();
  if (!pkg) return { used: 0, limit: 0, remaining: 0, resetAt: null, percent: 100 };
  if (pkg.id === "classic" || pkg.id === "pro") {
    const raw = localStorage.getItem(PACKAGE_KEY);
    const data = raw ? (JSON.parse(raw) as StoredPackage) : null;
    return {
      used: 0,
      limit: null,
      remaining: null,
      resetAt: data?.expiresAt || null,
      percent: 0,
    };
  }
  const raw = localStorage.getItem(COUNT_KEY);
  const now = Date.now();
  const record: { count: number; windowStart: number } = raw
    ? JSON.parse(raw)
    : { count: 0, windowStart: now };
  if (now - record.windowStart > 24 * 60 * 60 * 1000) {
    return { used: 0, limit: 4, remaining: 4, resetAt: now + 24 * 60 * 60 * 1000, percent: 0 };
  }
  return {
    used: record.count,
    limit: 4,
    remaining: 4 - record.count,
    resetAt: record.windowStart + 24 * 60 * 60 * 1000,
    percent: (record.count / 4) * 100,
  };
}

/** ADMIN-ONLY: approve an order by id, activating the package for that user */
export function adminApproveOrder(orderId: string): Order | null {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === orderId);
  if (idx === -1) return null;
  orders[idx].status = "approved";
  orders[idx].reviewedAt = Date.now();
  saveOrders(orders);
  approvePackageForUser(orders[idx].userEmail, orders[idx].packageId);
  return orders[idx];
}

export function adminRejectOrder(orderId: string): Order | null {
  const orders = getOrders();
  const idx = orders.findIndex((o) => o.id === orderId);
  if (idx === -1) return null;
  orders[idx].status = "rejected";
  orders[idx].reviewedAt = Date.now();
  saveOrders(orders);
  return orders[idx];
}
