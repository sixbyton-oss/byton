import { Link } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import { PACKAGES } from "../utils/packageStorage";
import { getCurrentUser } from "../utils/auth";

export default function Home() {
  const user = getCurrentUser();

  return (
    <div className="flex">
      {/* Sidebar with Login category */}
      <Sidebar />

      <div className="flex-1 min-w-0">
        {/* HERO */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute left-1/2 top-0 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-lime-500/15 blur-3xl" />
            <div className="absolute right-0 top-40 h-[400px] w-[400px] rounded-full bg-red-500/15 blur-3xl" />
          </div>

          <div className="mx-auto max-w-6xl px-4 pb-24 pt-16 sm:px-6 sm:pt-24 lg:px-8 lg:pt-32">
            <div className="mx-auto max-w-3xl text-center">
              <span className="inline-flex items-center gap-2 rounded-full border border-lime-500/40 bg-lime-500/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-lime-300">
                <span className="h-1.5 w-1.5 rounded-full bg-lime-400" />
                Prompt → Website
              </span>
              <h1 className="mt-6 text-4xl font-black tracking-tight text-white sm:text-6xl lg:text-7xl">
                Type a prompt.{" "}
                <span className="bg-gradient-to-r from-lime-300 via-lime-400 to-lime-500 bg-clip-text text-transparent">
                  Get a website.
                </span>
              </h1>
              <p className="mt-6 text-lg leading-relaxed text-white/80 sm:text-xl">
                Webcraft turns plain English into deployable websites in seconds.
                Describe what you want — the AI builds it, you preview it, then
                download a ready-to-host ZIP.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Link
                  to={user ? "/builder" : "/signup"}
                  className="inline-flex items-center gap-2 rounded-xl bg-lime-400 px-7 py-3.5 text-base font-extrabold text-black shadow-xl shadow-lime-400/40 transition hover:bg-lime-300 hover:shadow-lime-400/60"
                >
                  {user ? "Open AI Builder" : "Start free"}
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="3">
                    <path d="M5 12h14M13 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </Link>
                <Link
                  to="/pricing"
                  className="inline-flex items-center gap-2 rounded-xl border-2 border-red-500/40 bg-red-500/10 px-7 py-3.5 text-base font-bold text-white transition hover:border-red-500/70 hover:bg-red-500/20"
                >
                  See pricing
                </Link>
              </div>
              <p className="mt-4 text-xs text-white/50">
                Free tier forever: 4 prompts/day • No credit card needed
              </p>
            </div>

            {/* Preview window */}
            <div className="mx-auto mt-16 max-w-5xl">
              <div className="overflow-hidden rounded-2xl border border-white/10 bg-black/60 shadow-2xl shadow-lime-500/10">
                <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
                  <span className="h-3 w-3 rounded-full bg-red-500" />
                  <span className="h-3 w-3 rounded-full bg-amber-500" />
                  <span className="h-3 w-3 rounded-full bg-lime-500" />
                  <div className="ml-3 flex-1 truncate rounded-md bg-white/5 px-3 py-1 text-xs text-white/60">
                    webcraft.app/builder
                  </div>
                </div>
                <div className="grid gap-4 p-6 sm:grid-cols-[1fr_1.4fr]">
                  <div className="space-y-3 rounded-xl border border-white/10 bg-black p-4">
                    <p className="text-xs font-bold uppercase tracking-wider text-white/50">Your prompt</p>
                    <p className="text-sm text-white/90">
                      "Build a clean landing page for a coffee subscription startup called{" "}
                      <span className="text-lime-300">Brewly</span>, with hero, features, pricing, and footer."
                    </p>
                    <button className="w-full rounded-lg bg-lime-400 py-2 text-xs font-extrabold text-black">
                      Generate ✨
                    </button>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white p-5">
                    <div className="mb-4 flex items-center justify-between">
                      <span className="text-lg font-black text-black">Brewly ☕</span>
                      <span className="rounded-full bg-lime-100 px-2 py-0.5 text-[10px] font-extrabold text-lime-800">LIVE</span>
                    </div>
                    <p className="text-sm text-slate-600">Fresh beans. Delivered weekly.</p>
                    <div className="mt-4 grid grid-cols-3 gap-2">
                      {["Single", "Double", "Family"].map((p) => (
                        <div key={p} className="rounded-lg border border-slate-200 p-2 text-center">
                          <div className="text-[10px] font-bold text-black">{p}</div>
                          <div className="text-xs text-slate-500">$9/mo</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-black text-white sm:text-4xl">Three steps. That's it.</h2>
            <p className="mt-3 text-white/70">From idea to live URL in under a minute.</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { n: "01", t: "Pick your package", d: "Starter is free — 4 prompts/day. Classic ($1) or Pro ($5) for unlimited.", c: "lime" },
              { n: "02", t: "Prompt the AI", d: "Describe your site. The AI builds it silently and sends back a summary.", c: "lime" },
              { n: "03", t: "Preview & deploy", d: "Hit Review for a live preview or Deploy for a downloadable ZIP.", c: "red" },
            ].map((s) => (
              <div key={s.n} className={`relative rounded-2xl border p-6 transition hover:-translate-y-0.5 ${
                s.c === "red" ? "border-red-500/40 bg-red-500/5 hover:border-red-500" : "border-white/10 bg-black/40 hover:border-lime-500/50"
              }`}>
                <span className={`text-5xl font-black ${s.c === "red" ? "text-red-500/30" : "text-lime-400/30"}`}>{s.n}</span>
                <h3 className="mt-2 text-lg font-bold text-white">{s.t}</h3>
                <p className="mt-2 text-sm text-white/70">{s.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* FEATURES */}
        <section className="border-y border-white/10 bg-black/60 py-20">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-black text-white sm:text-4xl">Built for makers, not coders</h2>
              <p className="mt-3 text-white/70">Everything you need to launch — nothing you don't.</p>
            </div>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { i: "⚡", t: "Instant generation", d: "Full HTML/CSS/JS sites generated in under 15 seconds." },
                { i: "🎨", t: "Pixel-perfect design", d: "Modern, responsive layouts on every device." },
                { i: "📦", t: "One-click ZIP export", d: "Download clean, deploy-ready code." },
                { i: "👀", t: "Live preview", d: "Review button shows your site before you download." },
                { i: "🔁", t: "Iterate with AI", d: "Ask for changes. 'Bigger hero.' 'Dark mode.' Done." },
                { i: "🚀", t: "Host anywhere", d: "Netlify, Vercel, GitHub Pages, your own server." },
              ].map((f) => (
                <div key={f.t} className="rounded-2xl border border-white/10 bg-black p-6 transition hover:border-lime-500/40">
                  <div className="text-3xl">{f.i}</div>
                  <h3 className="mt-3 font-bold text-white">{f.t}</h3>
                  <p className="mt-1 text-sm text-white/70">{f.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* PRICING PREVIEW */}
        <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-black text-white sm:text-4xl">Simple, honest pricing</h2>
            <p className="mt-3 text-white/70">Choose a package before prompting. No surprises.</p>
          </div>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {PACKAGES.map((p) => (
              <div
                key={p.id}
                className={`relative rounded-2xl border p-6 ${
                  p.highlight
                    ? "border-lime-400 bg-gradient-to-b from-lime-400/10 to-black shadow-xl shadow-lime-500/10"
                    : "border-white/10 bg-black/60"
                }`}
              >
                {p.badge && (
                  <span className="absolute -top-3 left-6 rounded-full bg-lime-400 px-3 py-0.5 text-xs font-extrabold text-black shadow-lg">
                    {p.badge}
                  </span>
                )}
                <h3 className="text-lg font-bold text-white">{p.name}</h3>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-4xl font-black text-white">{p.price}</span>
                  <span className="text-sm text-white/60">/ {p.period}</span>
                </div>
                <p className="mt-2 text-sm font-bold text-lime-300">{p.limit}</p>
                <ul className="mt-5 space-y-2 text-sm text-white/80">
                  {p.features.map((f) => (
                    <li key={f} className="flex gap-2">
                      <svg viewBox="0 0 24 24" className="mt-0.5 h-4 w-4 flex-shrink-0 text-lime-400" fill="none" stroke="currentColor" strokeWidth="3">
                        <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>
                <Link
                  to={p.requiresPayment ? "/signup?package=" + p.id : "/pricing"}
                  className={`mt-6 block rounded-lg px-4 py-2.5 text-center text-sm font-extrabold transition ${
                    p.highlight
                      ? "bg-lime-400 text-black hover:bg-lime-300"
                      : "border border-white/20 text-white hover:bg-white/5"
                  }`}
                >
                  {p.id === "starter" ? "Start free" : "Choose " + p.name}
                </Link>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="mx-auto max-w-5xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl border border-lime-400/30 bg-gradient-to-br from-lime-500/10 via-black to-red-500/10 p-10 text-center">
            <h2 className="text-3xl font-black text-white sm:text-4xl">Ready to craft?</h2>
            <p className="mx-auto mt-3 max-w-xl text-white/80">
              Join thousands turning ideas into real websites. Your first prompt is free.
            </p>
            <Link
              to={user ? "/builder" : "/signup"}
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-lime-400 px-6 py-3 text-base font-extrabold text-black transition hover:bg-lime-300"
            >
              Get started — it's free
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
