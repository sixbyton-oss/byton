import { Link, useNavigate } from "react-router-dom";
import { getCurrentUser, clearSession, isPremiumUser } from "../utils/auth";
import {
  getActivePackage,
  getStoredPackageData,
  getUsage,
  clearPackage,
} from "../utils/packageStorage";
import { getUserOrders, openWhatsApp } from "../utils/orders";

export default function Account() {
  const user = getCurrentUser();
  const navigate = useNavigate();
  const pkg = getActivePackage();
  const stored = getStoredPackageData();
  const premium = isPremiumUser();
  const usage = getUsage();
  const orders = user ? getUserOrders(user.email) : [];

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <div className="rounded-2xl border border-white/10 bg-black/60 p-8">
          <h1 className="text-xl font-bold text-white">Please log in</h1>
          <Link to="/login" className="mt-4 inline-block rounded-lg bg-lime-400 px-5 py-2 text-sm font-bold text-black">
            Login
          </Link>
        </div>
      </div>
    );
  }

  const latestOrder = orders[0];
  const isPending = stored?.status === "pending" || latestOrder?.status === "pending";
  const isApproved = stored?.status === "active" && pkg && pkg.id !== "starter";

  const handleLogout = () => {
    clearSession();
    clearPackage();
    navigate("/");
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col gap-4 rounded-2xl border border-white/10 bg-black/60 p-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-lime-400 to-lime-600 text-2xl font-black text-black shadow-lg shadow-lime-500/30">
            {user.username.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white">
              {user.username}
              {premium && <span className="ml-2 rounded-full bg-lime-400 px-2 py-0.5 text-xs font-bold text-black">PREMIUM ★</span>}
            </h1>
            <p className="text-sm text-white/60">{user.email}</p>
            <p className="mt-1 text-xs text-white/40">
              Member since {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm font-semibold text-red-300 hover:bg-red-500/20"
        >
          Log out
        </button>
      </div>

      {/* Status banner */}
      {isPending && latestOrder && (
        <div className="mt-6 rounded-2xl border border-amber-500/40 bg-amber-500/10 p-5">
          <div className="flex items-start gap-3">
            <div className="text-2xl">⏳</div>
            <div className="flex-1">
              <h3 className="font-bold text-amber-200">Payment pending approval</h3>
              <p className="mt-1 text-sm text-amber-100/80">
                Your EcoCash payment for the <strong>{latestOrder.packageId === "classic" ? "Classic" : "Pro"}</strong> plan has been received. The admin is reviewing it now. Once approved, your account will instantly upgrade to Premium.
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                <span className="rounded-md bg-black/40 px-2 py-1 text-amber-200">Order: {latestOrder.id}</span>
                <span className="rounded-md bg-black/40 px-2 py-1 text-amber-200">Code: {latestOrder.ecoCashCode}</span>
                <span className="rounded-md bg-black/40 px-2 py-1 text-amber-200">{latestOrder.amount}</span>
                <button
                  onClick={() => openWhatsApp(latestOrder)}
                  className="rounded-md bg-amber-400 px-2 py-1 font-bold text-black hover:bg-amber-300"
                >
                  Resend WhatsApp message
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {isApproved && (
        <div className="mt-6 rounded-2xl border border-lime-500/40 bg-lime-500/10 p-5">
          <div className="flex items-start gap-3">
            <div className="text-2xl">✅</div>
            <div className="flex-1">
              <h3 className="font-bold text-lime-200">Premium account active</h3>
              <p className="mt-1 text-sm text-lime-100/80">
                You're on the <strong>{pkg!.name}</strong> plan — {pkg!.limit}. Enjoy!
              </p>
              {stored?.expiresAt && (
                <p className="mt-1 text-xs text-lime-200/70">
                  Expires: {new Date(stored.expiresAt).toLocaleString()}
                </p>
              )}
              <Link
                to="/builder"
                className="mt-3 inline-block rounded-lg bg-lime-400 px-4 py-2 text-xs font-bold text-black hover:bg-lime-300"
              >
                Go to AI Builder →
              </Link>
            </div>
          </div>
        </div>
      )}

      {!pkg && (
        <div className="mt-6 rounded-2xl border border-white/10 bg-black/60 p-5">
          <p className="text-sm text-white/70">You don't have an active package yet.</p>
          <Link to="/pricing" className="mt-3 inline-block rounded-lg bg-lime-400 px-4 py-2 text-xs font-bold text-black hover:bg-lime-300">
            Choose a package
          </Link>
        </div>
      )}

      {/* Usage progress */}
      {pkg && (
        <div className="mt-6 rounded-2xl border border-white/10 bg-black/60 p-6">
          <h2 className="text-sm font-bold uppercase tracking-wider text-white/60">Prompt usage</h2>
          <div className="mt-3 flex items-baseline justify-between">
            <p className="text-lg font-bold text-white">
              {usage.remaining === null
                ? "Unlimited prompts"
                : `${usage.used} / ${usage.limit} prompts used`}
            </p>
            {usage.resetAt && (
              <p className="text-xs text-white/50">
                Resets {new Date(usage.resetAt).toLocaleString()}
              </p>
            )}
          </div>
          <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full rounded-full transition-all ${
                usage.percent >= 100 ? "bg-red-500" : usage.percent >= 75 ? "bg-amber-400" : "bg-lime-400"
              }`}
              style={{ width: `${Math.min(100, usage.percent)}%` }}
            />
          </div>
          {usage.remaining !== null && usage.remaining === 0 && (
            <p className="mt-3 text-sm text-red-300">
              You've used all prompts. Upgrade to Classic or Pro for unlimited prompts.
            </p>
          )}
        </div>
      )}

      {/* Order history */}
      <div className="mt-6 rounded-2xl border border-white/10 bg-black/60 p-6">
        <h2 className="text-sm font-bold uppercase tracking-wider text-white/60">Order history</h2>
        {orders.length === 0 ? (
          <p className="mt-3 text-sm text-white/50">No orders yet.</p>
        ) : (
          <div className="mt-3 divide-y divide-white/10">
            {orders.map((o) => (
              <div key={o.id} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-semibold text-white">
                    {o.packageId === "classic" ? "Classic" : "Pro"} plan — {o.amount}
                  </p>
                  <p className="text-xs text-white/50">
                    {o.id} · {new Date(o.submittedAt).toLocaleString()}
                  </p>
                </div>
                <span
                  className={`inline-flex w-fit items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
                    o.status === "approved"
                      ? "border border-lime-500/40 bg-lime-500/10 text-lime-300"
                      : o.status === "rejected"
                      ? "border border-red-500/40 bg-red-500/10 text-red-300"
                      : "border border-amber-500/40 bg-amber-500/10 text-amber-300"
                  }`}
                >
                  <span className={`h-1.5 w-1.5 rounded-full ${
                    o.status === "approved" ? "bg-lime-400" : o.status === "rejected" ? "bg-red-400" : "bg-amber-400 animate-pulse"
                  }`} />
                  {o.status.charAt(0).toUpperCase() + o.status.slice(1)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
