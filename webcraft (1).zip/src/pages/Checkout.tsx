import { useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { getCurrentUser } from "../utils/auth";
import { PACKAGES, selectPaidPackage, type PackageId } from "../utils/packageStorage";
import { createOrder, openWhatsApp } from "../utils/orders";

export default function Checkout() {
  const [sp] = useSearchParams();
  const packageParam = (sp.get("package") as PackageId) || "classic";
  const pkg = PACKAGES.find((p) => p.id === packageParam) || PACKAGES[1];
  const user = getCurrentUser();
  const navigate = useNavigate();

  const [ecoCashCode, setEcoCashCode] = useState("");
  const [senderNumber, setSenderNumber] = useState("");
  const [senderName, setSenderName] = useState(user?.username || "");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <div className="rounded-2xl border border-white/10 bg-black/60 p-8">
          <h1 className="text-xl font-bold text-white">Please log in first</h1>
          <p className="mt-2 text-sm text-white/60">You need an account to complete checkout.</p>
          <Link
            to={`/signup?package=${pkg.id}`}
            className="mt-4 inline-block rounded-lg bg-lime-400 px-5 py-2 text-sm font-bold text-black"
          >
            Sign up
          </Link>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!ecoCashCode.trim() || ecoCashCode.trim().length < 6) {
      setError("Please enter your EcoCash confirmation code");
      return;
    }
    if (!/^[0-9+\s]{7,}$/.test(senderNumber)) {
      setError("Please enter a valid sender phone number");
      return;
    }
    if (!senderName.trim()) {
      setError("Please enter the sender's full name");
      return;
    }

    setSubmitting(true);
    try {
      const order = createOrder({
        userEmail: user.email,
        username: user.username,
        packageId: pkg.id,
        amount: pkg.price,
        ecoCashCode: ecoCashCode.trim().toUpperCase(),
        senderNumber: senderNumber.trim(),
        senderName: senderName.trim(),
      });

      // Mark package as pending until admin approves
      selectPaidPackage(pkg.id as "classic" | "pro", user.email, order.id);

      // Open WhatsApp with pre-filled message
      openWhatsApp(order);

      setDone(true);
      setTimeout(() => navigate("/account"), 1500);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="rounded-2xl border border-white/10 bg-black/60 p-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-white/50">Checkout</p>
            <h1 className="mt-1 text-2xl font-extrabold text-white">
              Pay for <span className="text-lime-400">{pkg.name}</span>
            </h1>
          </div>
          <div className="rounded-xl border border-lime-400/30 bg-lime-400/10 px-4 py-2 text-right">
            <p className="text-xs text-white/60">Total</p>
            <p className="text-2xl font-black text-lime-300">{pkg.price}</p>
          </div>
        </div>

        {/* EcoCash instructions */}
        <div className="mt-6 rounded-xl border border-lime-400/30 bg-lime-400/5 p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-lime-400 text-xl text-black">💸</div>
            <div>
              <p className="text-sm font-bold text-white">Send {pkg.price} via EcoCash</p>
              <p className="text-xs text-white/60">Manual payment — we'll activate your account after verification</p>
            </div>
          </div>
          <div className="mt-4 rounded-lg bg-black/40 p-4">
            <p className="text-xs font-bold uppercase tracking-wider text-white/50">Send to developer's EcoCash account</p>
            <p className="mt-2 font-mono text-2xl font-black text-lime-300">0786 443 311</p>
            <p className="mt-1 text-xs text-white/60">
              Send exactly <strong className="text-white">{pkg.price}</strong> to the number above, then paste your confirmation code below.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-white/70">
              EcoCash confirmation code
            </label>
            <input
              type="text"
              required
              value={ecoCashCode}
              onChange={(e) => setEcoCashCode(e.target.value)}
              placeholder="e.g. MP2412.1234.A12345"
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 font-mono text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/70">Sender phone number</label>
              <input
                type="tel"
                required
                value={senderNumber}
                onChange={(e) => setSenderNumber(e.target.value)}
                placeholder="07XXXXXXXX"
                className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
              />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-white/70">Sender full name</label>
              <input
                type="text"
                required
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                placeholder="As it appears on EcoCash"
                className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
              />
            </div>
          </div>

          {error && (
            <div className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-300">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting || done}
            className="w-full rounded-lg bg-lime-400 py-3 text-sm font-extrabold text-black transition hover:bg-lime-300 disabled:opacity-50"
          >
            {submitting ? "Submitting…" : done ? "✓ Submitted — opening WhatsApp…" : "Submit & confirm on WhatsApp"}
          </button>

          <p className="text-center text-xs text-white/50">
            Clicking submit opens WhatsApp with your details pre-filled. Send the message to finish.
          </p>
        </form>

        <div className="mt-6 flex items-start gap-3 rounded-lg border border-white/10 bg-white/5 p-4 text-sm text-white/70">
          <span className="text-red-400">⚠️</span>
          <div>
            <p className="font-semibold text-white">Your order will be marked as "Pending"</p>
            <p className="mt-1">
              Once the admin verifies your EcoCash payment, your account will be upgraded to{" "}
              <strong className="text-lime-300">Premium {pkg.name}</strong>. You'll see the status on your account page.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
