import { useState } from "react";
import { getOrders, type Order } from "../utils/orders";
import { adminApproveOrder, adminRejectOrder } from "../utils/packageStorage";

const ADMIN_PASSWORD = "webcraft-admin-2026";

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");
  const [orders, setOrders] = useState<Order[]>(getOrders());

  const tryLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pw === ADMIN_PASSWORD) {
      setAuthed(true);
      setError("");
    } else {
      setError("Wrong password");
    }
  };

  const refresh = () => setOrders(getOrders());

  const handleApprove = (id: string) => {
    if (!confirm("Approve this order and activate the user's package?")) return;
    adminApproveOrder(id);
    refresh();
  };
  const handleReject = (id: string) => {
    if (!confirm("Reject this order?")) return;
    adminRejectOrder(id);
    refresh();
  };

  if (!authed) {
    return (
      <div className="mx-auto max-w-sm px-4 py-16">
        <div className="rounded-2xl border border-white/10 bg-black/60 p-6">
          <h1 className="text-xl font-bold text-white">Admin login</h1>
          <p className="mt-1 text-xs text-white/60">
            Demo password: <code className="rounded bg-white/10 px-1.5 py-0.5 text-lime-300">{ADMIN_PASSWORD}</code>
          </p>
          <form onSubmit={tryLogin} className="mt-4 space-y-3">
            <input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder="Admin password"
              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-white focus:border-lime-400 focus:outline-none"
            />
            {error && <p className="text-xs text-red-300">{error}</p>}
            <button className="w-full rounded-lg bg-lime-400 py-2 text-sm font-bold text-black">Enter</button>
          </form>
        </div>
      </div>
    );
  }

  const pending = orders.filter((o) => o.status === "pending");
  const reviewed = orders.filter((o) => o.status !== "pending");

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
      <h1 className="text-2xl font-extrabold text-white">Admin dashboard</h1>
      <p className="text-sm text-white/60">Approve EcoCash payments to activate user accounts.</p>

      <section className="mt-8">
        <h2 className="text-sm font-bold uppercase tracking-wider text-amber-300">Pending ({pending.length})</h2>
        {pending.length === 0 ? (
          <p className="mt-3 text-sm text-white/50">No pending orders.</p>
        ) : (
          <div className="mt-3 space-y-3">
            {pending.map((o) => (
              <div key={o.id} className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-bold text-white">{o.username} · {o.userEmail}</p>
                    <p className="text-xs text-white/60">{o.id} · {new Date(o.submittedAt).toLocaleString()}</p>
                  </div>
                  <span className="rounded-full bg-lime-400/20 px-3 py-1 text-xs font-bold text-lime-300">
                    {o.packageId.toUpperCase()} · {o.amount}
                  </span>
                </div>
                <div className="mt-3 grid gap-2 text-sm sm:grid-cols-3">
                  <div><p className="text-xs text-white/50">EcoCash code</p><p className="font-mono text-lime-300">{o.ecoCashCode}</p></div>
                  <div><p className="text-xs text-white/50">Sender number</p><p className="text-white">{o.senderNumber}</p></div>
                  <div><p className="text-xs text-white/50">Sender name</p><p className="text-white">{o.senderName}</p></div>
                </div>
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => handleApprove(o.id)}
                    className="rounded-lg bg-lime-400 px-4 py-1.5 text-xs font-bold text-black hover:bg-lime-300"
                  >
                    ✓ Approve & activate
                  </button>
                  <button
                    onClick={() => handleReject(o.id)}
                    className="rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-1.5 text-xs font-semibold text-red-300 hover:bg-red-500/20"
                  >
                    ✕ Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="text-sm font-bold uppercase tracking-wider text-white/60">Reviewed ({reviewed.length})</h2>
        {reviewed.length === 0 ? (
          <p className="mt-3 text-sm text-white/50">No reviewed orders.</p>
        ) : (
          <div className="mt-3 space-y-2">
            {reviewed.map((o) => (
              <div key={o.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-4 py-2 text-sm">
                <span className="text-white/80">{o.username} · {o.packageId} · {o.id}</span>
                <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                  o.status === "approved" ? "bg-lime-400/20 text-lime-300" : "bg-red-500/20 text-red-300"
                }`}>
                  {o.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
