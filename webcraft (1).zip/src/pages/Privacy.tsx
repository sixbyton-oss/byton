import { Link } from "react-router-dom";

export default function Privacy() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <Link to="/" className="text-xs text-white/60 hover:text-lime-300">← Back to home</Link>
      <h1 className="mt-4 text-4xl font-black text-white">Privacy Policy</h1>
      <p className="mt-2 text-sm text-white/50">Last updated: January 2026</p>

      <div className="mt-8 space-y-6 text-white/80">
        <section>
          <h2 className="text-xl font-bold text-white">1. Introduction</h2>
          <p>Webcraft ("we", "our", "us") is committed to protecting your privacy. This policy explains what information we collect and how we use it.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">2. Information we collect</h2>
          <ul className="list-disc space-y-2 pl-6">
            <li><strong className="text-white">Account data:</strong> username, email, password (hashed).</li>
            <li><strong className="text-white">Payment data:</strong> EcoCash confirmation codes, sender name, sender number.</li>
            <li><strong className="text-white">Usage data:</strong> prompts you send to the AI, generated outputs, feature usage.</li>
            <li><strong className="text-white">Device data:</strong> IP address, browser type.</li>
          </ul>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">3. How we use your information</h2>
          <ul className="list-disc space-y-2 pl-6">
            <li>Generate websites based on your prompts</li>
            <li>Verify and activate paid packages</li>
            <li>Provide support via email or WhatsApp</li>
            <li>Prevent abuse and fraud</li>
          </ul>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">4. Third-party services</h2>
          <p>The AI chatbot is powered by <a href="https://easy-peasy.ai" className="text-lime-300 underline">easy-peasy.ai</a>. Prompts sent through the chat widget are processed by their service.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">5. Your rights</h2>
          <ul className="list-disc space-y-2 pl-6">
            <li>Access the data we hold about you</li>
            <li>Request deletion of your data</li>
            <li>Export your generated websites at any time</li>
          </ul>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">6. Contact</h2>
          <p>Email <a href="mailto:sixbyton@gmail.com" className="text-lime-300 underline">sixbyton@gmail.com</a> or WhatsApp <a href="https://wa.me/263786443311" className="text-lime-300 underline">+263 786 443 311</a>.</p>
        </section>
      </div>
    </article>
  );
}
