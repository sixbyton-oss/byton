import { Link } from "react-router-dom";

export default function Terms() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <Link to="/" className="text-xs text-white/60 hover:text-lime-300">← Back to home</Link>
      <h1 className="mt-4 text-4xl font-black text-white">Terms of Service</h1>
      <p className="mt-2 text-sm text-white/50">Last updated: January 2026</p>

      <div className="mt-8 space-y-6 text-white/80">
        <section>
          <h2 className="text-xl font-bold text-white">1. Acceptance</h2>
          <p>By using Webcraft, you agree to these Terms.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">2. Packages & payments</h2>
          <ul className="list-disc space-y-2 pl-6">
            <li><strong className="text-white">Starter (Free):</strong> 4 prompts per 24 hours.</li>
            <li><strong className="text-white">Classic ($1):</strong> unlimited prompts for 24 hours.</li>
            <li><strong className="text-white">Pro ($5):</strong> unlimited prompts for 7 days.</li>
            <li>Paid packages require signup + EcoCash payment to 0786 443 311.</li>
            <li>Payments are manually verified before activation.</li>
          </ul>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">3. Acceptable use</h2>
          <p>You agree not to generate illegal, malicious, or deceptive content.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">4. Ownership</h2>
          <p>You own all websites you generate. Use, sell, or modify them freely.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">5. Limitation of liability</h2>
          <p>Webcraft is provided "as is". We are not liable for indirect or consequential damages.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">6. Governing law</h2>
          <p>These Terms are governed by the laws of Zimbabwe.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">7. Contact</h2>
          <p>Email <a href="mailto:sixbyton@gmail.com" className="text-lime-300 underline">sixbyton@gmail.com</a> or WhatsApp <a href="https://wa.me/263786443311" className="text-lime-300 underline">+263 786 443 311</a>.</p>
        </section>
      </div>
    </article>
  );
}
