import { Link, useNavigate } from "react-router-dom";
import { PACKAGES, getActivePackage, selectStarter, type PackageId } from "../utils/packageStorage";
import { getCurrentUser } from "../utils/auth";

export default function Pricing() {
  const active = getActivePackage();
  const user = getCurrentUser();
  const navigate = useNavigate();

  const handleSelect = (id: PackageId) => {
    if (id === "starter") {
      if (!user) {
        navigate(`/signup?package=starter`);
        return;
      }
      selectStarter(user.email);
      navigate("/builder");
      return;
    }
    // Paid packages — require account + checkout
    if (!user) {
      navigate(`/signup?package=${id}`);
    } else {
      navigate(`/checkout?package=${id}`);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-4xl font-black tracking-tight text-white sm:text-5xl">
          Pick your package
        </h1>
        <p className="mt-4 text-lg text-white/70">
          Choose a package before prompting. Paid plans require signup + EcoCash payment.
        </p>
      </div>

      {active && (
        <div className="mx-auto mt-6 max-w-2xl rounded-xl border border-lime-500/40 bg-lime-500/10 p-4 text-center text-sm text-lime-200">
          You're on the <span className="font-bold">{active.name}</span> plan.{" "}
          <Link to="/builder" className="underline hover:text-white">Go to builder →</Link>
        </div>
      )}

      <div className="mt-12 grid gap-6 lg:grid-cols-3">
        {PACKAGES.map((p) => {
          const isActive = active?.id === p.id;
          return (
            <div
              key={p.id}
              className={`relative flex flex-col rounded-2xl border p-8 ${
                p.highlight
                  ? "border-lime-400 bg-gradient-to-b from-lime-400/10 to-black shadow-2xl shadow-lime-500/10"
                  : "border-white/10 bg-black/60"
              }`}
            >
              {p.badge && (
                <span className="absolute -top-3 left-8 rounded-full bg-lime-400 px-3 py-1 text-xs font-extrabold text-black shadow-lg">
                  {p.badge}
                </span>
              )}
              <h3 className="text-xl font-bold text-white">{p.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-5xl font-black text-white">{p.price}</span>
                <span className="text-white/60">/ {p.period}</span>
              </div>
              <p className="mt-2 text-sm font-bold text-lime-300">{p.limit}</p>
              <ul className="mt-6 flex-1 space-y-3 text-sm text-white/80">
                {p.features.map((f) => (
                  <li key={f} className="flex gap-2">
                    <svg viewBox="0 0 24 24" className="mt-0.5 h-4 w-4 flex-shrink-0 text-lime-400" fill="none" stroke="currentColor" strokeWidth="3">
                      <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handleSelect(p.id)}
                className={`mt-8 rounded-lg px-4 py-3 text-sm font-extrabold transition ${
                  isActive
                    ? "cursor-default bg-white/10 text-white/50"
                    : p.highlight
                    ? "bg-lime-400 text-black hover:bg-lime-300"
                    : "border border-white/20 text-white hover:bg-white/5"
                }`}
              >
                {isActive ? "✓ Current plan" : p.id === "starter" ? "Start free" : `Get ${p.name}`}
              </button>
              {p.requiresPayment && (
                <p className="mt-2 text-center text-xs text-white/50">
                  Requires signup + EcoCash payment
                </p>
              )}
            </div>
          );
        })}
      </div>

      <div className="mx-auto mt-16 max-w-3xl rounded-2xl border border-white/10 bg-black/60 p-6">
        <h3 className="font-bold text-white">Frequently asked</h3>
        <dl className="mt-4 space-y-4 text-sm">
          <div>
            <dt className="font-semibold text-white">Do I need a package to use the builder?</dt>
            <dd className="mt-1 text-white/70">Yes. Starter gives you 4 free prompts per 24 hours, forever.</dd>
          </div>
          <div>
            <dt className="font-semibold text-white">How do I pay for Classic or Pro?</dt>
            <dd className="mt-1 text-white/70">
              Sign up → you'll be taken to checkout → send the amount via EcoCash to{" "}
              <span className="font-mono text-lime-300">0786 443 311</span> → enter your confirmation code → submit.
              We'll activate your account after verification.
            </dd>
          </div>
          <div>
            <dt className="font-semibold text-white">Can I host the ZIP anywhere?</dt>
            <dd className="mt-1 text-white/70">Yes. Netlify, Vercel, GitHub Pages, Cloudflare Pages, or any shared hosting.</dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
