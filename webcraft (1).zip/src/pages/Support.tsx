export default function Support() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-4xl font-black tracking-tight text-white sm:text-5xl">We're here to help</h1>
        <p className="mt-4 text-lg text-white/70">Stuck on a prompt? Payment question? Bug report? Reach us any way you like.</p>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-2">
        <a
          href="https://wa.me/263786443311"
          target="_blank"
          rel="noreferrer"
          className="group rounded-2xl border border-lime-400/30 bg-lime-400/5 p-6 transition hover:border-lime-400 hover:bg-lime-400/10"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-lime-400/20 text-lime-300 text-2xl">💬</div>
          <h3 className="mt-4 text-lg font-bold text-white">WhatsApp support</h3>
          <p className="mt-1 text-sm text-white/70">Fastest way to reach us. Usually replies within minutes.</p>
          <p className="mt-3 font-mono text-sm text-lime-300 group-hover:text-lime-200">+263 786 443 311 →</p>
        </a>

        <a
          href="mailto:sixbyton@gmail.com"
          className="group rounded-2xl border border-red-500/30 bg-red-500/5 p-6 transition hover:border-red-500 hover:bg-red-500/10"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-red-500/20 text-red-300 text-2xl">✉️</div>
          <h3 className="mt-4 text-lg font-bold text-white">Email us</h3>
          <p className="mt-1 text-sm text-white/70">For detailed questions, billing, or partnerships.</p>
          <p className="mt-3 font-mono text-sm text-red-300 group-hover:text-red-200">sixbyton@gmail.com →</p>
        </a>
      </div>

      <div className="mt-12 rounded-2xl border border-white/10 bg-black/60 p-8">
        <h2 className="text-xl font-bold text-white">Frequently asked questions</h2>
        <div className="mt-6 space-y-5">
          {[
            { q: "How do I activate Classic or Pro after paying?", a: "Send us a WhatsApp message or email with your payment proof. We'll activate your plan within 1 hour (usually faster)." },
            { q: "What payment methods do you accept?", a: "EcoCash to 0786 443 311. For international users, reach out for PayPal arrangements." },
            { q: "Can I use the generated sites commercially?", a: "Yes — 100%. You own everything Webcraft generates for you." },
            { q: "My prompts ran out on Starter. What now?", a: "Wait for your 24-hour window to reset, or upgrade to Classic ($1) for unlimited prompts for 24 hours." },
            { q: "Where can I host the ZIP file?", a: "Anywhere that serves static HTML: Netlify Drop, Vercel, GitHub Pages, Cloudflare Pages, or any shared hosting." },
            { q: "Can I get a refund?", a: "Refunds are case-by-case. If the AI genuinely couldn't produce anything useful for your use case, contact us." },
          ].map((f) => (
            <div key={f.q} className="border-b border-white/10 pb-5 last:border-0">
              <h3 className="font-semibold text-white">{f.q}</h3>
              <p className="mt-2 text-sm text-white/70">{f.a}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-12 rounded-2xl border border-lime-400/30 bg-gradient-to-br from-lime-500/10 via-black to-red-500/10 p-8 text-center">
        <h2 className="text-xl font-bold text-white">Still need help?</h2>
        <p className="mt-2 text-sm text-white/80">Message us directly — we respond to everyone personally.</p>
        <div className="mt-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a href="https://wa.me/263786443311" className="rounded-lg bg-lime-400 px-5 py-2.5 text-sm font-extrabold text-black hover:bg-lime-300">Chat on WhatsApp</a>
          <a href="mailto:sixbyton@gmail.com" className="rounded-lg border-2 border-red-500/40 bg-red-500/10 px-5 py-2.5 text-sm font-bold text-white hover:bg-red-500/20">Send an email</a>
        </div>
      </div>
    </div>
  );
}
