import { Link } from "react-router-dom";

export default function Cookies() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
      <Link to="/" className="text-xs text-white/60 hover:text-lime-300">← Back to home</Link>
      <h1 className="mt-4 text-4xl font-black text-white">Cookie Policy</h1>
      <p className="mt-2 text-sm text-white/50">Last updated: January 2026</p>

      <div className="mt-8 space-y-6 text-white/80">
        <section>
          <h2 className="text-xl font-bold text-white">Essential storage</h2>
          <ul className="list-disc space-y-2 pl-6">
            <li><strong className="text-white">webcraft_users:</strong> your account information (locally).</li>
            <li><strong className="text-white">webcraft_session:</strong> your current logged-in email.</li>
            <li><strong className="text-white">webcraft_package:</strong> your selected package.</li>
            <li><strong className="text-white">webcraft_prompt_count:</strong> your prompt usage counter.</li>
            <li><strong className="text-white">webcraft_orders:</strong> your payment submissions.</li>
          </ul>
          <p className="mt-2">All stored locally in your browser. Not sent to our servers.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">Third-party cookies</h2>
          <p>The easy-peasy.ai chat widget may set its own cookies to maintain your session.</p>
        </section>
        <section>
          <h2 className="text-xl font-bold text-white">Contact</h2>
          <p>Email <a href="mailto:sixbyton@gmail.com" className="text-lime-300 underline">sixbyton@gmail.com</a>.</p>
        </section>
      </div>
    </article>
  );
}
