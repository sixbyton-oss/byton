import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { signup, setSession } from "../utils/auth";
import { PACKAGES, type PackageId } from "../utils/packageStorage";

export default function Signup() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [sp] = useSearchParams();
  const packageParam = (sp.get("package") as PackageId) || null;
  const targetPkg = packageParam ? PACKAGES.find((p) => p.id === packageParam) : null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirm) {
      setError("Passwords do not match");
      return;
    }
    setLoading(true);
    try {
      const user = await signup(username, email, password);
      setSession(user.email);

      // Route based on whether they came here for a paid package
      if (targetPkg?.requiresPayment) {
        navigate(`/checkout?package=${targetPkg.id}`);
      } else if (packageParam === "starter") {
        // Activate starter immediately
        const { selectStarter } = await import("../utils/packageStorage");
        selectStarter(user.email);
        navigate("/builder");
      } else {
        navigate("/pricing");
      }
    } catch (err: any) {
      setError(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md items-center px-4 py-12 sm:px-6">
      <div className="w-full rounded-2xl border border-white/10 bg-black/60 p-8 shadow-2xl shadow-lime-500/5">
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-lime-400 to-lime-600 text-2xl text-black shadow-lg shadow-lime-500/30">
            🚀
          </div>
          <h1 className="mt-4 text-2xl font-extrabold text-white">Create your account</h1>
          <p className="mt-1 text-sm text-white/60">
            {targetPkg?.requiresPayment
              ? `Sign up to activate your ${targetPkg.name} (${targetPkg.price}) plan`
              : "Get started in seconds"}
          </p>
        </div>

        {targetPkg?.requiresPayment && (
          <div className="mt-4 flex items-center justify-between rounded-lg border border-lime-500/30 bg-lime-500/10 px-3 py-2 text-sm">
            <span className="text-white/80">Selected plan:</span>
            <span className="font-bold text-lime-300">
              {targetPkg.name} · {targetPkg.price}
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-white/70">Username</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
              placeholder="yourname"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-white/70">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-white/70">Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
              placeholder="At least 6 characters"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-white/70">Confirm password</label>
            <input
              type="password"
              required
              minLength={6}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-white placeholder:text-white/30 focus:border-lime-400 focus:outline-none focus:ring-2 focus:ring-lime-400/30"
              placeholder="Repeat password"
            />
          </div>

          {error && (
            <div className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-300">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-lime-400 py-3 text-sm font-extrabold text-black transition hover:bg-lime-300 disabled:opacity-50"
          >
            {loading ? "Creating account…" : targetPkg?.requiresPayment ? `Sign up & checkout ${targetPkg.price}` : "Sign up"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-white/60">
          Already have an account?{" "}
          <Link to="/login" className="font-semibold text-lime-300 hover:text-lime-200">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
